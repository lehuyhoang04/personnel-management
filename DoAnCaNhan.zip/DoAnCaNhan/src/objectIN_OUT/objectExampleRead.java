/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objectIN_OUT;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 *
 * @author DELL
 */
public class objectExampleRead {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        FileInputStream fis= null;
        ObjectInputStream ois = null;
        try{
            fis = new FileInputStream(".\\src\\objectIN_OUT\\object.dat");
            ois = new  ObjectInputStream(fis);
            Stock[] stocks1 = (Stock[]) ois.readObject();
            System.out.println("doc file: ");
            for(Stock s: stocks1){
                System.out.println(s);
            }
            ois.close();fis.close();
        }catch(IOException | ClassNotFoundException e){
            System.out.println("co loi: "+e);
        }
    }
}
