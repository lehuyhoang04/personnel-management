/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
C:\Users\DELL\Documents\NetBeansProjects\Chuong2_java2\src\objectIN_OUT\object.dat
 */
package objectIN_OUT;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 *
 * @author DELL
 */
public class objectExampleWrite {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        try (ObjectOutputStream oos = new  ObjectOutputStream(new FileOutputStream(".\\src\\objectIN_OUT\\object.dat"))) {
            Stock[] stocks = {new Stock(1001, "CD rom", 100.00, 20),
                new Stock(1002, "Dram", 100.00, 20),
                new Stock(1003, "p4 processor", 343.00, 22),
                new Stock(1004, "cannot jet", 140.00, 30),
                new Stock(1005, "HP channel", 350.00, 50),
                new Stock(1006, "CD rom", 400.00,60)
            };
            oos.writeObject(stocks);
        }
}
}