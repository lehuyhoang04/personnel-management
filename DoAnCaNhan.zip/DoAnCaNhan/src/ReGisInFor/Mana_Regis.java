/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ReGisInFor;

/**
 *
 * @author DELL
 */
public class Mana_Regis {
    private String Id;
    private String Surname;
    private String Email;
    private String Address;
    private String Contact;

    public Mana_Regis() {
    }

    public Mana_Regis(String Id, String Surname, String Email, String Address, String Contact) {
        this.Id = Id;
        this.Surname = Surname;
        this.Email = Email;
        this.Address = Address;
        this.Contact = Contact;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getSurname() {
        return Surname;
    }

    public void setSurname(String Surname) {
        this.Surname = Surname;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getContact() {
        return Contact;
    }

    public void setContact(String Contact) {
        this.Contact = Contact;
    }
    
}
