/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
C:\Users\DELL\Documents\NetBeansProjects\Chuong2_java2\src\CRUD_application\database
 */
package ReGisInFor;

import demo2.NhanVien;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class InforManaFunc {
     ArrayList<Mana_Regis> ds = new ArrayList<>();

    public InforManaFunc() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(".\\src\\CRUD_application\\database"));
            String line = reader.readLine();
            int countLine = 0;
            while (line != null) {
                countLine += 1;

//                System.out.println(line);
                String[] dataRow = line.split("[|]");
                String Id = dataRow[0];
                String Surname = dataRow[1];
                String Email = dataRow[2];
                String Address = dataRow[3];
                String Contact = dataRow[4];
                ds.add(new Mana_Regis(Id, Surname, Email, Address, Contact));
                line = reader.readLine();
            }
            
            reader.close();
        } catch (IOException e) {
            System.out.println(e.toString());
        }

    }
}
