/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
C:\Users\DELL\Documents\NetBeansProjects\Chuong2_java2\src\demoLamLai\dataSV
 */
package demoLamLai;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class ChucnangQLSV {

    ArrayList<SinhVien> dsSV = new ArrayList<>();

    public ChucnangQLSV()  {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(".\\src\\demoLamLai\\dataSV.txt"));
            String line = reader.readLine();
            int countLine = 0;
            while (line != null) {
                countLine += 1;
                String[] dataRow = line.split("[|]");
                String maSV = dataRow[0];
                String HoTen = dataRow[1];
                String Email = dataRow[2];
                String GioiTinh = dataRow[3];
                String TinhTrang = dataRow[4];
                dsSV.add(new SinhVien(maSV,HoTen,Email,GioiTinh,TinhTrang));
                line = reader.readLine();
            }
            reader.close();
        }catch(IOException e){
            System.out.println(e.toString());
        }
        
    }
}
