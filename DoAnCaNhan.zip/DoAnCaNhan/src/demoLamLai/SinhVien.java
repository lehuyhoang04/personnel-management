/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demoLamLai;

/**
 *
 * @author DELL
 */
public class SinhVien {
     private String maSV;
   private String HoTen;
   private String email;
   private String GioiTinh;
   private String TinhTrang;

    public SinhVien() {
    }

    public SinhVien(String maSV, String HoTen, String email, String GioiTinh, String TinhTrang) {
        this.maSV = maSV;
        this.HoTen = HoTen;
        this.email = email;
        this.GioiTinh = GioiTinh;
        this.TinhTrang = TinhTrang;
    }

    public String getMaSV() {
        return maSV;
    }

    public void setMaSV(String maSV) {
        this.maSV = maSV;
    }

    public String getHoTen() {
        return HoTen;
    }

    public void setHoTen(String HoTen) {
        this.HoTen = HoTen;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(String GioiTinh) {
        this.GioiTinh = GioiTinh;
    }

    public String getTinhTrang() {
        return TinhTrang;
    }

    public void setTinhTrang(String TinhTrang) {
        this.TinhTrang = TinhTrang;
    }
    

}