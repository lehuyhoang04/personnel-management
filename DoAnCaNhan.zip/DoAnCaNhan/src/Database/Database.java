/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Database;

/**
 *
 * @author MSI
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
    public static Connection connect() {
        Connection conn = null;
        try {
            // Đường dẫn tới file database, file này sẽ nằm cùng thư mục project
            String url = "jdbc:sqlite:database.db";
            conn = DriverManager.getConnection(url);
            System.out.println("Kết nối SQLite thành công.");
        } catch (SQLException e) {
            System.out.println("Lỗi kết nối SQLite: " + e.getMessage());
        }
        return conn;
    }
}

