/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author DELL
 */
public class docFile2 {
    public static void main(String[] args) {
        try{
            BufferedReader reader = new BufferedReader(new FileReader("./src/demo4/file2.txt"));
            String line = reader.readLine();
            int countLine = 0;
            while(line != null){
                countLine += 1;
                System.out.println(line);
                line = reader.readLine();
            }
            System.out.println("count line = "+ countLine);
            reader.close();
        }catch (IOException e) {
            System.out.println(e.toString());
        }
    }
}
