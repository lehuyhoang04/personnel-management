/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
C:\Users\DELL\Documents\NetBeansProjects\Chuong2_java2\src\demo4\file_text.java
 */
package demo4;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.Buffer;

/**
 *
 * @author DELL
 */
public class ghifile2 {

    public static void main(String[] args){
        try {
            BufferedWriter writer = new BufferedWriter(
                   new FileWriter("./src/demo4/file2.txt"));
//            writer.write("line 1");
//            writer.newLine();
//            writer.write("line2\n");
//            writer.write("line3");
            for (int i = 1; i <= 10; i++){
                String s = "Line" + i;
                if (i < 10) s += "\n";
                writer.write(s);
                    
                
            }
            writer.close();
            System.out.println("Done");
        } catch (IOException e) {
            System.out.println(e.toString());
        }
    }
}
