/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo4;

import java.io.FileOutputStream;

/**
 C:\Users\DELL\Documents\NetBeansProjects\Chuong2_java2\src\demo4\GhiFile.java
 * @author DELL
 */
public class GhiFile {
    public static void main(String[] args) {
        try{
            FileOutputStream fos = new FileOutputStream("./src/demo4/fo.dat");
            String s = "Hello, i am cntt1_22";
            byte [] data = s.getBytes();
            fos.write(data);
            fos.close();
        
        }catch(Exception e){
            System.out.println("loi: "+ e.toString());
        }
    }
}
