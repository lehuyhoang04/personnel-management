/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo4;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author DELL
 */
public class DocFile {
    public static void main(String[] args) throws FileNotFoundException, IOException{
    try{
        FileInputStream fis = new FileInputStream("./src/demo4/fo.dat");
        int c;
        String s ="";
        while ((c = fis.read()) != -1) {
            s += (char) c;
        }
        System.out.println("ket qua doc file: " + s );
    }catch (Exception e){
        System.out.println("loi"+ e.toString());
    }

    }
}